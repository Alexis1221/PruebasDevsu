package com.serenity.stepdefinition;

import com.serenity.steps.CompraSteps;
import com.serenity.steps.MiCarritoSteps;
import com.serenity.steps.LoginSteps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;

public class IngresoSesionStepDefinition {
	@Steps
	LoginSteps user;
	@Given("que ingreso a la web")
	public void que_ingreso_a_la_web() {
		user.cargaWeb();
	}

}
