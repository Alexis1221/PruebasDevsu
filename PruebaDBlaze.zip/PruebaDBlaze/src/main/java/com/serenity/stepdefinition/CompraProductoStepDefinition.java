package com.serenity.stepdefinition;

import com.serenity.steps.LoginSteps;
import com.serenity.steps.CompraSteps;
import com.serenity.steps.MiCarritoSteps;
import com.serenity.steps.ProductosSteps;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;

import java.io.IOException;

public class CompraProductoStepDefinition {
	@Steps
	ProductosSteps prodcutosSteps;
	@Steps
	MiCarritoSteps carritoSteps;
	@Steps
	CompraSteps compraSteps;
	@Steps
	CompraSteps myAccountSteps;
	@When("^selecciono el producto (.*)$")
	public void selecciono_el_producto(String Producto) {
		prodcutosSteps.seleccionarProducto(Producto);
	}
	@When("^agrego al carrito el producto$")
	public void agregol_producto() {
		prodcutosSteps.agregoProducto();
	}
	@When("^completo el formulario de compra con (.*),(.*),(.*),(.*),(.*) y (.*)$")
	public void completarFormulario(String Nombre,String Pais,String Ciudad,String Tarjeta,String mes,String year){
		compraSteps.llenarInformacionDelCliente(Nombre,Pais,Ciudad,Tarjeta,mes,year);
	}
	@When("^finalizo la compra$")
	public void finalizar_compra() {
		compraSteps.finalizarCompra();
	}
	@When("^ingresamos al carrito$")
	public void ingresamos_al_carrito() throws IOException {
		carritoSteps.ingresamos_al_carrito();
	}
	@When("^realizamos el pedido$")
	public void realizamos_pedido() throws IOException {
		carritoSteps.realizamos_pedido();
	}
	@Then("^debo ver el mensaje de confirmación \"Thank you for your purchase!\"$")
	public void validar_mensaje_confirmacion() {
		myAccountSteps.validarMensajeConfirmacion();
	}
}
