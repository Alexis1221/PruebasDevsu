package com.serenity.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class CompraPage extends PageObject{
	@FindBy(id ="name")
	WebElementFacade txtNombre;
	@FindBy(id ="country")
	WebElementFacade txtPais;
	@FindBy(id ="city")
	WebElementFacade txtCiudad;
	@FindBy(id ="card")
	WebElementFacade txtTarjeta;
	@FindBy(id ="month")
	WebElementFacade txtmes;
	@FindBy(id ="year")
	WebElementFacade txtyear;
	@FindBy(id ="continue")
	WebElementFacade btnContinuarCompra;
	@FindBy(xpath ="//*[@id=\"orderModal\"]/div/div/div[3]/button[2]")
	WebElementFacade btnFinalizarCompra;

	public void finalizarCompra() {
		btnFinalizarCompra.waitUntilClickable().click();
	}
	public void ingresarInformacionDelCliente(String Nombre,String Pais,String Ciudad,String Tarjeta,String mes,String year) {

		txtNombre.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtNombre.type(Nombre);
		txtPais.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtPais.type(Pais);
		txtCiudad.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtCiudad.type(Ciudad);
		txtTarjeta.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtTarjeta.type(Tarjeta);
		txtmes.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtmes.type(mes);
		txtyear.withTimeoutOf(10, TimeUnit.SECONDS).waitUntilVisible();
		txtyear.type(year);

	}
	public String obtenerMensajeConfirmacion() {
		WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
		WebElement mensaje = wait.until(
				ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//h2[contains(text(),'Thank you for your purchase!')]")
				)
		);
		return mensaje.getText();
	}
}