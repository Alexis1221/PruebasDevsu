package com.serenity.pages;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.Serenity;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class CarritoPage extends PageObject{

	@FindBy(xpath ="//*[@id=\"cartur\"]")
	WebElementFacade btnCarrito;
	@FindBy(xpath ="//*[@id=\"page-wrapper\"]/div/div[2]/button")
	WebElementFacade btnRealizarPedido;


	public void ingresamos_al_carrito() throws IOException {
		btnCarrito.waitUntilClickable().click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.getStackTrace();
		}
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Serenity.takeScreenshot();
	}
	public void realizamos_pedido() throws IOException {
		btnRealizarPedido.waitUntilClickable().click();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Serenity.takeScreenshot();
	}

}