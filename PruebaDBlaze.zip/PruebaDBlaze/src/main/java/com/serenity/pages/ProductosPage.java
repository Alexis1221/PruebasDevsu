package com.serenity.pages;

import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.time.Duration;

public class ProductosPage extends PageObject{
	private static final Logger log = LoggerFactory.getLogger(CompraPage.class);

	@FindBy(xpath ="//*[@id=\"tbodyid\"]/div[2]/div/a")
	WebElementFacade btnAgregarCarrito;
	@FindBy(xpath ="//*[@id=\"navbarExample\"]/ul/li[1]/a")
	WebElementFacade btnHome;

	public void agregoProducto( ) {

		WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));

		btnAgregarCarrito.waitUntilClickable().click();
		wait.until(ExpectedConditions.alertIsPresent());
		getDriver().switchTo().alert().accept();
		btnHome.waitUntilClickable().click();
	}

	public void seleccionarProducto(String Producto) {

		log.info("Selecciono producto "+Producto);

		getDriver().findElement(
				By.xpath("//a[text()='" + Producto + "']")
		).click();

		log.info("Selecciono producto "+Producto);
	}

}
