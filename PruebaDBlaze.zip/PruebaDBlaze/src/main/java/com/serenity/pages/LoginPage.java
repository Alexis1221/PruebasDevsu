package com.serenity.pages;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class LoginPage extends PageObject{
	private static final Logger log = LoggerFactory.getLogger(LoginPage.class);

	public void cargaWeb() {
		log.info("cargando la web.");
		open();
		getDriver().manage().window().maximize();
	}
}
