package com.serenity.steps;

import com.serenity.pages.LoginPage;

import net.serenitybdd.annotations.Step;

public class LoginSteps {
	private LoginPage loginPage;
	@Step
	public void cargaWeb() {
		loginPage.cargaWeb();
	}
}
