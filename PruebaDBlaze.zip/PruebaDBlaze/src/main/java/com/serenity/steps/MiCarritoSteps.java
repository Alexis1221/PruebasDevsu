package com.serenity.steps;

import com.serenity.pages.CarritoPage;
import java.io.IOException;

public class MiCarritoSteps {
	private CarritoPage user;
	public void ingresamos_al_carrito() throws IOException {
		user.ingresamos_al_carrito();
	}
	public void realizamos_pedido() throws IOException {
		user.realizamos_pedido();
	}

}
