package com.serenity.steps;

import com.serenity.pages.*;
import net.serenitybdd.annotations.Step;

public class ProductosSteps {
	private ProductosPage user;
	@Step
	public void seleccionarProducto(String Producto) {
		user.seleccionarProducto(Producto);
	}
	public void agregoProducto() {
		user.agregoProducto();
	}

}
