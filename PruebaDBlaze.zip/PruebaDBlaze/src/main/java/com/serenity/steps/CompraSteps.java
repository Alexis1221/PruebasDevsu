package com.serenity.steps;

import com.serenity.pages.CompraPage;
import org.junit.Assert;

import com.serenity.pages.ProductosPage;
import com.serenity.pages.CarritoPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

public class CompraSteps {
	private CompraPage compra;

	public void llenarInformacionDelCliente(String Nombre,String Pais,String Ciudad,String Tarjeta,String mes,String year) {
		// La lógica de asignación vive aquí, NO en el Page ni en el Definition
		compra.ingresarInformacionDelCliente(Nombre,Pais,Ciudad,Tarjeta,mes,year);
	}
	public void finalizarCompra() {
		compra.finalizarCompra();
	}
	public void validarMensajeConfirmacion() {
		String mensajeConfirmacion = compra.obtenerMensajeConfirmacion();
		System.out.println("Mensaje : " + mensajeConfirmacion);
		assertThat("La cantidad de productos en el carrito no es la esperada",
				mensajeConfirmacion, equalTo("Thank you for your purchase!"));

		System.out.println("PASO" + mensajeConfirmacion);
	}
}
