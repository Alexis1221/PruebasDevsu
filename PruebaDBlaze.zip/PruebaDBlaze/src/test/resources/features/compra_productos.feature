@CompraProducto
Feature: Compra Producto

  Background:
    Given que ingreso a la web

  Scenario Outline: Compra de prodcuctos
    When selecciono el producto <producto1>
    And agrego al carrito el producto
    And selecciono el producto <producto2>
    And agrego al carrito el producto
    And ingresamos al carrito
    When realizamos el pedido
    And completo el formulario de compra con <Nombre>,<Pais>,<Ciudad>,<Tarjeta>,<mes> y <year>
    And finalizo la compra
    Then debo ver el mensaje de confirmación "Thank you for your purchase!"

    Examples:
   |producto1|producto2|Nombre|Pais|Ciudad|Tarjeta|mes|year|
   |Samsung galaxy s6|Nexus 6|Juan|Peru|Lima|12345678|02|2020|