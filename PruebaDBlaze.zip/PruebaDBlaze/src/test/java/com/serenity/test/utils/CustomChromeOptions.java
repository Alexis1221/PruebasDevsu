package com.serenity.test.utils;
import org.openqa.selenium.chrome.ChromeOptions;
import java.util.HashMap;
import java.util.Map;
public class CustomChromeOptions {
    public static ChromeOptions getChromeOptions() {
        ChromeOptions options = new ChromeOptions();

        Map<String, Object> prefs = new HashMap<>();
        // CLAVE: Desactiva la detección de fugas de contraseñas
        prefs.put("profile.password_manager_leak_detection", false);
        prefs.put("credentials_enable_service", false); // Desactiva "Guardar contraseña"
        prefs.put("profile.password_manager_enabled", false);
        options.setExperimentalOption("prefs", prefs); // Aplica las preferencias

        // Opciones adicionales para estabilidad
        options.addArguments("--disable-extensions");
        options.addArguments("--no-sandbox");
        options.addArguments("--start-maximized");

        return options;
    }
}
