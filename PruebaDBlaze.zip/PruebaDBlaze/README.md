# 🧪 Serenity BDD Automation Project "Demoblaze"

Proyecto de automatización de pruebas **E2E (End to End)** utilizando **Serenity BDD**, **Cucumber**, **Selenium WebDriver** y **Java**, orientado a validar flujos funcionales de compra en aplicaciones web.

---
## 📌 Heramientas
- **Intellij
- **git

## 📌 Tecnologías utilizadas

- **Java 17**
- **Serenity BDD 4.x**
- **Cucumber (BDD)**
- **Selenium WebDriver**
- **Maven**
- **JUnit**
- **Chrome**
- **Selenium Manager (gestión automática de drivers)**

## 📌 Plugin
- **Ccumber for java**
- **Gherkin**
---

## 🌐 Aplicación bajo prueba

- URL: https://www.demoblaze.com/index.html

---


---

## 🧾 Escenario automatizado (E2E)

El proyecto cubre el siguiente flujo:

1. Ingresar web
2. Agregar 2 productos al carrito
3. Visualizar carrito
4. Completar formulario de compra
5. Finalizar compra
6. Validar mensaje de confirmación:
   > **"Thank you for your purchase!"**

---

## 🧠 Patrón utilizado

- **Page Object Model (POM)**
- **BDD (Behavior Driven Development)**

---

## ⚙️ Configuración (`serenity.properties`)

## **Running Test:**
Ejecución por comando

```
mvn serenity:aggregate verify
```

**Una vez que se complete la ejecución de los scripts, se generará un informe en la carpeta *target/site/serenity/index.html*.**

Creado por: Alexis Alayo
