@karate
Feature: Login API Demo

  Background:
    * url base_Url
    * def crearMascota = karate.read('classpath:data/crearMascota.csv')
    * def editarMascota = karate.read('classpath:data/editarMascota.csv')
    * def estadoMascota = karate.read('classpath:data/estadoMascota.csv')

  @createPet @Regresion
  Scenario Outline: Crear mascota

    Given request
      """
      {
        "id": <id>,
        "category": {
          "id": <categoryId>,
          "name": "<categoryName>"
        },
        "name": "<petName>",
        "photoUrls": [
          "string"
        ],
        "tags": [
          {
            "id": <tagId>,
            "name": "<tagName>"
          }
        ],
        "status": "available"
      }
      """
    When method post
    Then status 200
    And match response.name == "<petName>"
    And match response.id == <id>
    And print response.name
    * def petId = response.id

    Examples:
      | karate.read('classpath:data/crearMascota.csv') |

  @Regresion
  Scenario: Busqueda por id de mascota
    * call read('compra.feature@createPet')
    Given path petId
    When method get
    Then status 200
    And print response

  @Regresion
  Scenario Outline: Editar nombre y estado de la mascota
    * call read('compra.feature@createPet')
    Given path '/' + petId
    And form field name = '<nombre>'
    And form field status = '<estado>'
    When method post
    Then status 200
    And print response

    Examples:
      | karate.read('classpath:data/editarMascota.csv') |

  @Regresion
  Scenario Outline: Busqueda por estado de la mascota
    Given path 'findByStatus'
    And param status = '<estado>'
    When method get
    Then status 200
    And print response
    And match each response[*].status == 'sold'

    Examples:
      | karate.read('classpath:data/estadoMascota.csv') |
