function fn() {
  karate.configure('ssl',true)
  var env = karate.env;
  var base_Url = '';

  if (!env) {
    env = 'dev';
  }
  if (env == 'dev') {
    karate.log('Ejecutando en ambiente DEV');
    base_Url = 'https://petstore.swagger.io/v2/pet/';

  }

  var config = {
    env: env,
    base_Url: base_Url

  };

  return config;
}
